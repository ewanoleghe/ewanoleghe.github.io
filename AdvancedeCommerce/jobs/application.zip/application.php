<?php 
$number = mt_rand(10000000, 99999999);			
	if(ISSET($_POST['update'])){
	
			$tName = $_POST['rName'];
			$tLocat = $_POST['rLocat'];
			$tField = $_POST['rField'];
			$tCountry = $_POST['rCountry'];
			$tCode = $_POST['rCode'];
			
				  }
		else{
			
				echo ("<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=index.php?id=$number\">");
			} 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>GSI - Genjir&#333; Steel Industries Japan Inc</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style type="text/css">
<!--
.style1 {
	color: #E60000;
	font-weight: bold;
}
.style3 {font-weight: bold}
-->
  </style>
</head>
<body>

<div id=':1m5' class='a3s aiL msg8561839825299154859'><u></u>
  <div style="width:800px; margin:0 auto;">
    <center>
      <table align='center' border='0' cellpadding='0' cellspacing='0' height='100%' width='100%' id='m_8561839825299154859bodyTable' role='presentation'>
	<tbody><tr>
		<td align='center' valign='top' id='m_8561839825299154859bodyCell'>
			<table border='0' cellpadding='0' cellspacing='0' id='m_8561839825299154859templateContainer' role='presentation'>
				<tbody><tr>
	<td align='left' valign='top'>
		<table border='0' cellpadding='0' cellspacing='0' width='100%' id='m_8561839825299154859templatePreheader' style='background-color:#ffffff;border-bottom:1px solid #cccccc' role='presentation'>
			<tbody><tr></tr>
				<tr></tr>
		</tbody></table>
	</td>
</tr>
<tr></tr>
<tr>
	<td align='left' valign='top'>
		<table border='0' cellpadding='0' cellspacing='0' width='100%' id='m_8561839825299154859templateFooter' role='presentation'>
			<tbody><tr>
				<td valign='top' class='m_8561839825299154859footerContent' style='color:#666666'><div class="jobs-content">
                  <div id="careers-page-job">
                    <div class="job-content-header">
                      <div class="job-title-container">
                        <div class="job-content-header">
                          <div class="job-title-container">
                            <h1><img src="logo.png" alt="GSI Jobs" width="268" height="61" /></h1>
                            <h1>&nbsp;</h1>
                            <div class="job-content-header">
                              <div class="job-title-container">
                                <h2><?php echo $tName; ?></h2>
                                <div class="job-content-location-category"> <span class="job-content-location style3"> <?php echo $tLocat; ?> </span>
                                    <div class="job-content-category-mobile"></div>
                                  <span class="job-content-category"><strong><?php echo $tField; ?></strong></span> </div>
                              </div>
                              <div data-react-class="HiringThing.Components.ApplyButtonGroup" data-react-props="{&quot;backToAllJobsLink&quot;:&quot;&quot;,&quot;formID&quot;:&quot;application-form-container&quot;,&quot;jobObj&quot;:{&quot;table&quot;:{&quot;id&quot;:461073,&quot;company_id&quot;:33478,&quot;company_name&quot;:&quot;Gevo, Inc.&quot;,&quot;title&quot;:&quot;Project Manager&quot;,&quot;abstract&quot;:&quot;\u003cstrong\u003e\u003cstrong\u003eAbout the role:\u003c/strong\u003e\u003c/strong\u003e The Project Manager is responsible for leading Capital Projects from origination through development, detailed design, procurement, construction, start-up and commissioning to help develop, deploy and improve Gevo’s unique and proprietary chemical process technology across multiple sites. The Project Manager will lead the development and execution of Capital Projects through…&quot;,&quot;html_description&quot;:&quot;\u003cp\u003e\u003cstrong\u003e\u003c/strong\u003e\u003cstrong\u003e\u003cstrong\u003eAbout the role:\u003c/strong\u003e\u003c/strong\u003e\u003c/p\u003e\u003cp\u003eThe Project Manager is responsible for leading Capital Projects from origination through development, detailed design, procurement, construction, start-up and commissioning to help develop, deploy and improve Gevo’s unique and proprietary chemical process technology across multiple sites.\u0026nbsp; The Project Manager will lead the development and execution of Capital Projects through planning, coordinating, tracking, and reporting of all project execution activities and perform work individually or lead a team across functional departments in a multidisciplinary environment utilizing both inside and outside resources to complete the assigned work.\u0026nbsp; Key technological areas will focus on solids handling, enzymatic reactions, fermentation, distillation, evaporation, catalytic reactions, fractional distillation, hydrocarbon purification, utilities, and process safety.\u0026nbsp; This position will also provide project management support to other functional groups within the organization as required to achieve Gevo’s Business Objectives.\u0026nbsp; These additional Departments include, but are not limited to, Plant Operation, Plant Maintenance, Safety-Health and Environmental, Business Development and Regulatory Compliance.\u003c/p\u003e\u003cp\u003e\u003cstrong\u003eWho You Are\u003c/strong\u003e\u003c/p\u003e\u003cul\u003e\u003cli\u003eHave ten or more years of experience with capital      project management within the petro-chemical or refinery industry; and/or\u0026nbsp;\u003c/li\u003e\u003cli\u003eExperience with      renewable fuels manufacturing and the renewable energy industry preferably      in sectors sensitive to carbon intensity and carbon footprint. \u0026nbsp;  \u003c/li\u003e\u003cli\u003eExperience with      development and execution of medium to large size capital projects in the      chemical process industry in OSHA / PSM regulated environments.  \u003c/li\u003e\u003cli\u003eExperience with multiple      project delivery methods including EPC contracts, Modular Fabrication      contracts, Detailed Engineering contracts, and Consulting Engineering      Services contracts.  \u003c/li\u003e\u003cli\u003eExperience with      commercial project execution, scheduling and tracking software such as MS      Project or Primavera P6. \u003c/li\u003e\u003cli\u003eAbility to work closely with project originators and vested parties to understand the ultimate project goals, requirements and constraints and provide technical expertise to define project deliverables, scopes of work, work breakdown structures, essential resources, and projections of cost and schedule as required by Gevo’s stage-gate project development and approval process.\u003cp\u003e  \u003c/p\u003e\u003c/li\u003e\u003cli\u003eEffective\u0026nbsp; working remotely and have the ability to travel to work sites to work for weeks at a time as necessary during project development.\u003c/li\u003e\u003cli\u003ePlan project execution activities, strategies, and methods of delivery.\u0026nbsp; Organize project execution teams and provide direction, coordination, tracking and overall management of team activities in furtherance of project goals.  \u003c/li\u003e\u003cli\u003eDirect, coordinate and track project design and engineering efforts from inside or outside resources of various disciplines as required by the project. \u0026nbsp;Design and engineering efforts may include, but not limited to, material and energy balances, process modeling, PFD’s, P\u0026amp;ID’s, equipment specifications, process descriptions, process hazards analysis, plant layouts, general arrangement drawings, site civil design, foundations, structural steel, piping design, electrical design, and instrumentation \u0026amp; controls.  \u003c/li\u003e\u003cli\u003eManage development of project cost estimates and cash flow projections of different types and accuracies as required by the stage-gate approval process.\u0026nbsp; These may include, but are not limited to, preliminary estimates, budgetary estimates, and definitive (Contractor) estimates and cash flow curves.\u0026nbsp; The Project Manager will be responsible for cost controls measures during execution either individually or in collaboration with other project team members.   \u003c/li\u003e\u003cli\u003eManage preparation and update of detailed project schedules for all scope of work and milestones. \u0026nbsp;The Project Manager will be responsible for schedule controls measures during execution either individually or in collaboration with other project team members.  \u003c/li\u003e\u003cli\u003eManage project procurement process by coordinating delivery of specifications and/or drawings for equipment, materials, and services to vendors/contractors, qualifying vendors, reviewing and approving vendor submittals, preparing Bid packages and leading Bids reviews and awards.\u0026nbsp; Project Manager will also be heavily involved in development of contract documents and contract negotiations with vendors or contractors.  \u003c/li\u003e\u003cli\u003ePrepare or lead the preparation of project progress reports to management, peers, and all other vested parties including updates on safety, scope, milestones, cost, schedule, progress vs. plan status and any other items relevant to project execution.\u0026nbsp;   \u003c/li\u003e\u003cli\u003eDevelop and oversee multidisciplinary project team during construction made up of both internal and external resources including management of mobilization, staging, personnel loading, safety-health-environmental compliance, quality control and quality assurance, conformance to contractual requirements, field engineering, pre-start-up walk-downs and check-outs, start-up, commissioning, final as-build documentation and ensures a sound and orderly project transfer to Operations team.  \u003c/li\u003e\u003cli\u003eLead conflict resolution and contract enforcement efforts, manage the change order process, provide official work acceptance, review and approve payment of invoices, and become a focal point for communication between all parties by organizing periodic meetings and publishing project information on a timely basis.  \u003c/li\u003e\u003cli\u003eWork in a collaborative way with all other members of the organization across department lines, functional groups and disciplines in support of Gevo’s process technology development and deployment across multiple sites as required by direct supervisor.\u003c/li\u003e\u003c/ul\u003e\u003cp\u003e\u003cstrong\u003eWho We Are\u003c/strong\u003e\u003c/p\u003e\u003cul\u003e  \u003cli\u003eWe are      People First  \u003c/li\u003e\u003cli\u003eWe are      Mission-Focused  \u003c/li\u003e\u003cli\u003eWe are      Agile  \u003c/li\u003e\u003cli\u003eWe are      Innovators\u003c/li\u003e\u003c/ul\u003e\u003cp\u003e\u003cstrong\u003eGevo \u003c/strong\u003eis a next generation, “low-carbon” fuel company focused on the development and commercialization of renewable alternatives to petroleum-based products. Low-carbon fuels reduce the carbon intensity, or the level of greenhouse gas emissions, compared to standard fossil-based fuels across their lifecycle. The most common low-carbon fuels are renewable fuels. Gevo is focused on the development and production of mainstream fuels like gasoline and jet fuel using renewable feedstocks that have the potential to lower greenhouse gas emissions at a meaningful scale and enhance agricultural production, including food and other related products.\u0026nbsp;\u003c/p\u003e\u003cp\u003e\u003cstrong\u003eWhat Gevo Offers You\u003c/strong\u003e  \u003c/p\u003e\u003cul\u003e\u003cli\u003eFree health, dental, vision, life and disability insurance for employee and family  \u003c/li\u003e\u003cli\u003e21 days of paid vacation and sick leave\u0026nbsp; plus 10 paid holidays  \u003c/li\u003e\u003cli\u003e401k contribution plan\u0026nbsp;  \u003c/li\u003e\u003cli\u003eAnnual incentive plan, based on Company performance  \u003c/li\u003e\u003cli\u003ePaid community service time  \u003c/li\u003e\u003cli\u003eDog friendly office  \u003c/li\u003e\u003cli\u003eBe part of a smart, high performing, passionate team  \u003c/li\u003e\u003cli\u003eWork-from-home stipend, if remote\u003c/li\u003e\u003c/ul\u003e\u003cp\u003e\u003cstrong\u003eSalary (for Colorado only)\u003c/strong\u003e  \u003c/p\u003e\u003cp\u003eOur salary ranges are based on national averages. We have wide ranges so we can be flexible and determine compensation based on a number of factors including the candidate's skills, level of experience, and location (which can be anywhere in the US). For Colorado-based candidates, the salary range for this position starts at $157,000 per year.\u0026nbsp; Compensation at all other locations will be based on the factors as stated above.\u003c/p\u003e\u003cp\u003e\u003cstrong\u003eCommitment to Diversity and Inclusion\u003c/strong\u003e  \u003c/p\u003e\u003cp\u003eGevo, Inc. is an equal opportunity employer that is committed to diversity and inclusion in the workplace. We prohibit discrimination and harassment of any kind based on race, color, sex, religion, sexual orientation, national origin, disability, genetic information, pregnancy, or any other protected characteristic as outlined by federal, state, or local laws.\u003c/p\u003e&quot;,&quot;url&quot;:&quot;/job/461073/project-manager&quot;,&quot;joblink_url&quot;:&quot;https://gevo-inc-careers.rippling-ats.com/job/461073/project-manager&quot;,&quot;posted_at&quot;:&quot;2022-07-25T06:28:00-06:00&quot;,&quot;location&quot;:&quot;Remote - Englewood, CO&quot;,&quot;location_info&quot;:{&quot;country&quot;:&quot;US&quot;,&quot;address&quot;:&quot;&quot;,&quot;city&quot;:&quot;Englewood&quot;,&quot;state&quot;:&quot;CO&quot;,&quot;zipcode&quot;:&quot;&quot;},&quot;job_code&quot;:&quot;1000040&quot;,&quot;category&quot;:&quot;Science and Engineering&quot;,&quot;enable_application_address_completion?&quot;:true,&quot;allow_job_board_applications&quot;:false,&quot;collect_linkedin_profile?&quot;:true,&quot;is_address_enabled?&quot;:true,&quot;is_address_required?&quot;:false,&quot;show_contact_preference?&quot;:true,&quot;resume_upload_enabled?&quot;:true,&quot;resume_upload_required?&quot;:false,&quot;coverletter_upload_enabled?&quot;:true,&quot;coverletter_upload_required?&quot;:false,&quot;other_upload_enabled?&quot;:true,&quot;referral_required?&quot;:true,&quot;referral_options&quot;:[&quot;Indeed.com&quot;,&quot;Craigslist&quot;,&quot;Monster.com&quot;,&quot;Jobdango&quot;,&quot;TalentZoo&quot;,&quot;CareerBuilder&quot;,&quot;Friend/Colleague&quot;,&quot;Recruiter&quot;,&quot;LinkedIn&quot;],&quot;disclosure_agreement&quot;:null,&quot;captcha_enabled?&quot;:false,&quot;remote&quot;:true,&quot;max_salary&quot;:{},&quot;min_salary&quot;:{},&quot;pay_frequency&quot;:&quot;hourly&quot;,&quot;show_remote_in_location&quot;:true,&quot;external_apply_url&quot;:null,&quot;questions&quot;:[]},&quot;modifiable&quot;:true},&quot;labelTranslations&quot;:{&quot;back_to_jobs&quot;:&quot;Back to Jobs&quot;,&quot;apply_for_this_position&quot;:&quot;Apply for this Position&quot;,&quot;back_to_wl_jobs&quot;:&quot;All Jobs at Rippling ATS&quot;},&quot;lang&quot;:&quot;en&quot;,&quot;recaptchaSiteKey&quot;:&quot;6Le5hLsSAAAAAE43yKMBj3XR8Ox2GNeDD4VYZx_5&quot;,&quot;showGDPRDisclosure&quot;:true,&quot;showNotify&quot;:true,&quot;showReferral&quot;:true,&quot;source&quot;:null,&quot;widgetMode&quot;:true,&quot;showBackButtons&quot;:true}" class="apply-button-group">
                                <div class="apply-buttons">
                                  <div align="center"><a href="index.php">
                                    <button class="btn large light" text="Back to Jobs" aria-label="Back to Jobs button" type="button"><span>Back to Jobs</span></button>
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="job-content-form" id="application-form-container">
		<form class="form-horizontal" role="form" method="post" action="process.php" enctype="multipart/form-data">
                                <div class="MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-3 ob grid css-1h77wgb">
                                  <div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 ob grid css-15j76c0">
                                    <div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0">
                                      <h3 class="app-subheader"><?php echo $tName; ?> Application Form - Job Code: <?php echo $tCode; ?></h3>
                                    </div>
                                  </div>
                                  <div class="hidden-fields">
                                    <div class="MuiFormControl-root MuiTextField-root ob text-input input css-i44wyl" form="[object Object]" options="">
                                      <div class="MuiInputBase-root MuiOutlinedInput-root MuiInputBase-colorPrimary MuiInputBase-fullWidth MuiInputBase-formControl css-1bp1ao6">
                                        <fieldset aria-hidden="true" class="MuiOutlinedInput-notchedOutline css-igs3ac">
                                          <legend class="css-hdw1oc"><span class="notranslate">​</span></legend>
										  
   <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12">
        <div class="card card-registration card-registration-2" style="border-radius: 15px;">
          <div class="card-body p-0">
            <div class="row g-0">
              <div class="col-lg-6">
                <div class="p-5">
                  <h3 class="fw-normal mb-5" >General Infomation</h3>              
                  <hr><div class="row">
                    <div class="col-md-6 mb-4 pb-2">

                      <div class="form-outline">
                        <input type="text" name="mFnom" id="mFnom" class="form-control form-control-lg"  required/>
                        <label class="form-label" for="form3Examplev2">First name</label>
                      </div>

                    </div>
                    <div class="col-md-6 mb-4 pb-2">

                      <div class="form-outline">
                        <input type="text" name="mLnom" id="form3Examplev3" class="form-control form-control-lg"  required/>
                        <label class="form-label" for="form3Examplev3">Last name</label>
                      </div>

                    </div>
					<div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0"><p>&nbsp;</p></div>
					<div class="col-md-6 mb-4 pb-2">

                      <div class="form-outline">
                        <input type="text" name="mEmail" id="form3Examplev2" class="form-control form-control-lg"  required/>
                        <label class="form-label" for="form3Examplev2">Email Address</label>
                      </div>

                    </div>
                    <div class="col-md-6 mb-4 pb-2">

                      <div class="form-outline">
                        <input type="text" name="mPhone" id="form3Examplev3" class="form-control form-control-lg"  maxlength="12" required/>
                        <label class="form-label" for="form3Examplev3">Phone Number</label>
                      </div>

                    </div>
					<div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0"><p>&nbsp;</p></div>
                  </div>	
                  </div>				
                   
					 <div class="mb-4 pb-2">
                    <div class="form-outline form-white">
                      <input type="text" name="mAdd1" id="form3Examplea2" class="form-control form-control-lg"  required/>
                      <label class="form-label" for="form3Examplea2">Address 1 [Street + Nr]</label>
                    </div>
                  </div>

                  <div class="mb-4 pb-2">
                    <div class="form-outline form-white">
                      <input type="text" name="mAdd2" id="form3Examplea3" class="form-control form-control-lg" />
                      <label class="form-label" for="form3Examplea3">Address 2</label>
                    </div>
                  </div>

					<div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0"><p>&nbsp;</p></div>

                  <div class="row">
                    <div class="col-md-5 mb-4 pb-2">

                      <div class="form-outline form-white">
                        <input type="text" name="mZip" id="form3Examplea4" class="form-control form-control-lg"  maxlength="7" required/>
                        <label class="form-label" for="form3Examplea4">Zip / Post Code</label>
                      </div>

                    </div>
                    <div class="col-md-7 mb-4 pb-2">

                      <div class="form-outline form-white">
                        <input type="text" name="mState" id="form3Examplea5" class="form-control form-control-lg"  required/>
                        <label class="form-label" for="form3Examplea5">State / Province</label>
                      </div>

                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-5 mb-4 pb-2">

                      <div class="form-outline form-white">
                        <input type="text" name="mCountry" id="form3Examplea7" class="form-control form-control-lg"  required/>
                        <label class="form-label" for="form3Examplea7">Country</label>
                      </div>

                    </div>
                    <div class="col-md-7 mb-4 pb-2">

                      <div class="form-outline form-white">
					  <?php $ndate = date("Y-m-d"); ?>
                        <input type="date" name="mDate" id="form3Examplea8" class="form-control form-control-lg" min="<?php echo $ndate; ?>"  required/>
                        <label class="form-label" for="form3Examplea8">Available start date</label>
                      </div>

                    </div>
                  </div>
					<div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0"><p>&nbsp;</p></div>
                  <div class="mb-4">
                    <div class="form-outline form-white">
                      <input class="form-control form-control-lg" id="xFile[]" name="xFile"  type="file" required/>
                      <label class="form-label" for="form3Examplea9">Upload your CV/Resume or any other relevant file. Max file size 50 MB</label>
                    </div>
                  </div>
				<hr>
				  <div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0">
                                      <h3 class="app-subheader">Contact Preference</h3>
                                  <h6 class="style1">You must enter a valid US phone number to enable SMS                                  </h6></div>				  
				  <div class="row">
                    <div class="col-md-5 mb-4 pb-2">

                      <div class="form-outline form-white">
                        <input class="form-check-input" type="checkbox" name="mContactPref-Email" id="gridCheck" checked>
                        <label class="form-label" for="form3Examplea4">Email</label>
                      </div>

                    </div>
                    <div class="col-md-7 mb-4 pb-2">

                      <div class="form-outline form-white">
                        <input class="form-check-input" type="checkbox" name="mContactPref-SMS" id="gridCheck">
                        <label class="form-label" for="form3Examplea5">SMS</label>
                      </div>

                    </div>
					
					<div class="col-md-7 mb-4 pb-2">
<div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0">
                                      <h3 class="app-subheader">Work Authorization</h3>
                                  </div>
                      <div class="ob form-control checkbox">
                        <input class="form-check-input" type="checkbox" name="mAuthorized" id="workAuth" required <?php if (isset($mAuthorized) && $mAuthorized=="mAuthorized") echo "checked";?>
value="Authorize to Work in ">
                        <label class="form-label" for="form3Examplea5">Authorize to Work in <?php echo $tCountry; ?></label>
                      </div>

                    </div>
                  </div>
				  
				  <hr>
				  <div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0">
                                      <h3 class="app-subheader">Additional Information</h3>
                                  </div>
									
				   <div class="mb-4">
                    <div class="form-outline form-white">
					 <div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 ob grid css-15j76c0">
                                    <div class="form-field-container disclosure-field-container " tabindex="-1" id="gdpr_disclosure_agree_label">
                                      <p class="dislosure-statement">Please review and agree to our <a class="disclosure-link" href="applicant_privacy_policy.php" target="_blank">Candidate Privacy Policy</a>. Your privacy is important to us, and your agreement allows us to process and retain your information for purposes of recruitment and employment.</p>
                                      <div class="form-input-container ">
                                        <div class="ob form-group horizontal">
                                          <div class="ob form-control checkbox">
                                            <label>
                                              <input type="checkbox" name="mReadPriv" id="gdpr_disclosure_agree" required <?php if (isset($mReadPriv) && $mAuthorized=="mReadPriv") echo "checked";?>
value="1">
                                              I have read and agree to the terms of the Candidate Privacy Policy.</label>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 ob grid css-15j76c0">
                                    <div class="ob form-group horizontal" tabindex="-1" id="subscribe_label">
                                      <div class="ob form-control checkbox">
                                        <label>
                                          <input type="checkbox" options="" name="mSubscribe" id="subscribe" <?php if (isset($mSubscribe) && $mSubscribe=="mSubscribe") echo "checked";?>
value="2">
                                          Subscribe! Please notify me of new opportunities as they are posted.</label>
                                      </div>
                                    </div>
                                  </div>
					</div>
              </div>
			  <input name="rName" type="hidden" value="<?php echo $tName; ?>" />
			<input name="rLocat" type="hidden" value="<?php echo $tLocat; ?>" />
			<input name="rField" type="hidden" value="<?php echo $tField; ?>" />
			<input name="rCountry" type="hidden" value="<?php echo $tCountry; ?>" />
			<input name="rCode" type="hidden" value="<?php echo $tCode; ?>" />
					<div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 ob grid css-15j76c0"><p>&nbsp;</p></div>
<div class="ob button-group withMargin">
                                      <button class="btn btn-success btn-lg btn-block" name="submit" type="submit" text="Submit Application" aria-label="Submit Application submit button"><span>Submit Application</span></button>
                                  </div>

                </div>
              </div>
				
                </div>
              </div>
             
			 
			 
            </div>
          </div>
        </div>
                              <p>&nbsp;</p>
                              </form>
                            

    <p>&nbsp;</p>
    <p>&nbsp;</p>
</body>
</html>
